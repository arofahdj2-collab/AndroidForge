package com.ffunbanpro.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val navy = Color.rgb(7, 22, 41)
    private val panel = Color.rgb(16, 36, 59)
    private val blue = Color.rgb(22, 139, 255)
    private val pale = Color.rgb(225, 239, 255)
    private lateinit var playerId: EditText
    private lateinit var details: EditText
    private lateinit var issueGroup: RadioGroup
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        buildScreen()
    }

    private fun rounded(color: Int, radius: Float = 18f): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(navy) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 28)
        }
        scroll.addView(page)
        setContentView(scroll)

        val heading = TextView(this).apply {
            text = "🛡  FF UNBAN PRO"
            textSize = 28f
            setTextColor(blue)
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(heading)

        val subtitle = TextView(this).apply {
            text = "PENDAMPING PENGAJUAN BANDING AKUN"
            textSize = 12f
            setTextColor(pale)
            setPadding(0, 5, 0, 22)
        }
        page.addView(subtitle)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            background = rounded(panel)
        }
        page.addView(card, matchWrap())

        label(card, "ID PEMAIN FREE FIRE")
        playerId = EditText(this).apply {
            hint = "Masukkan ID pemain"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            singleLine = true
            setPadding(14, 12, 14, 12)
            background = rounded(Color.rgb(31, 54, 78), 12f)
        }
        card.addView(playerId, matchWrap())

        label(card, "JENIS MASALAH AKUN")
        issueGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val permanent = radio("Banned permanen")
        val temporary = radio("Suspend sementara")
        issueGroup.addView(permanent)
        issueGroup.addView(temporary)
        issueGroup.check(permanent.id)
        card.addView(issueGroup)

        label(card, "KETERANGAN (OPSIONAL)")
        details = EditText(this).apply {
            hint = "Ceritakan masalah akun secara singkat"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            minLines = 3
            gravity = Gravity.TOP
            setPadding(14, 12, 14, 12)
            background = rounded(Color.rgb(31, 54, 78), 12f)
        }
        card.addView(details, matchWrap())

        val make = actionButton("BUAT SURAT BANDING")
        make.setOnClickListener { makeLetter() }
        page.addView(make, buttonParams())

        output = TextView(this).apply {
            textSize = 14f
            setTextColor(pale)
            setPadding(16, 16, 16, 16)
            visibility = View.GONE
            background = rounded(panel)
        }
        page.addView(output, matchWrap())

        val share = actionButton("BAGIKAN SURAT")
        share.setOnClickListener {
            val letter = output.text.toString()
            if (letter.isBlank()) {
                Toast.makeText(this, "Buat surat terlebih dahulu.", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, letter)
                }
                startActivity(Intent.createChooser(intent, "Bagikan surat banding"))
            }
        }
        page.addView(share, buttonParams())

        val help = actionButton("BUKA GAR​ENA SUPPORT")
        help.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://ffsupport.garena.com/"))
            startActivity(intent)
        }
        page.addView(help, buttonParams())

        val note = TextView(this).apply {
            text = "PENTING\nAplikasi ini hanya membantu menyiapkan permohonan pemeriksaan akun. FF UNBAN PRO bukan aplikasi resmi Garena, tidak dapat membuka banned secara otomatis, dan tidak menjamin akun dipulihkan. Jangan masukkan kata sandi atau kode OTP."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(4, 18, 4, 4)
        }
        page.addView(note, matchWrap())
    }

    private fun label(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(blue)
            setPadding(0, 18, 0, 8)
        })
    }

    private fun radio(textValue: String): RadioButton =
        RadioButton(this).apply {
            text = textValue
            textSize = 14f
            setTextColor(pale)
            id = View.generateViewId()
            buttonTintList = android.content.res.ColorStateList.valueOf(blue)
        }

    private fun actionButton(textValue: String) = Button(this).apply {
        text = textValue
        textSize = 13f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(blue, 14f)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun buttonParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 12 }

    private fun makeLetter() {
        val id = playerId.text.toString().trim()
        if (id.isEmpty()) {
            playerId.error = "ID pemain wajib diisi"
            return
        }
        val selected = findViewById<RadioButton>(issueGroup.checkedRadioButtonId)?.text
            ?: "Masalah akun"
        val explanation = details.text.toString().trim().ifEmpty {
            "Saya memohon pemeriksaan ulang atas pembatasan akun saya."
        }
        output.text = """
            PERMOHONAN PEMERIKSAAN AKUN FREE FIRE

            ID Pemain: $id
            Jenis masalah: $selected

            Keterangan:
            $explanation

            Kepada Tim Dukungan Garena,
            Saya memohon agar akun saya diperiksa kembali. Mohon informasikan alasan pembatasan serta prosedur resmi yang dapat saya ikuti.

            Terima kasih.
        """.trimIndent()
        output.visibility = View.VISIBLE
        Toast.makeText(this, "Surat banding berhasil dibuat.", Toast.LENGTH_SHORT).show()
    }
}
