# FF UNBAN PRO

Project Android sederhana dengan Kotlin (tanpa library pihak ketiga).

## Membuka project
1. Ekstrak ZIP.
2. Buka Android Studio.
3. Pilih **Open** lalu pilih folder `FF_UNBAN_PRO`.
4. Tunggu Gradle Sync selesai. Koneksi internet diperlukan saat pertama kali mengunduh Android Gradle Plugin.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Setelah selesai, tekan **locate** pada notifikasi build untuk menemukan APK.

## Fitur
- Input ID pemain Free Fire.
- Pilihan banned permanen / suspend sementara.
- Kolom keterangan masalah.
- Membuat dan membagikan surat banding.
- Membuka situs dukungan Free Fire.

## Catatan
Aplikasi ini bukan produk resmi Garena. Aplikasi hanya membantu menyiapkan permohonan pemeriksaan akun; tidak melewati sanksi, tidak menjamin pemulihan, dan tidak meminta password atau OTP.

## Konfigurasi
- Package: `com.ffunbanpro.app`
- Minimum Android: 6.0 (API 23)
- Compile SDK: 35
- Bahasa: Kotlin
